package org.mktab.cinama.model;

public enum Role {

    ADMIN,CUSTOMER,CINEMA
}
